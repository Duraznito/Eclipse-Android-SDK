package com.example.frr;



import android.os.Bundle;
import android.app.Activity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	public EditText id,nombre,cantidad,precio,nombre2,cantidad2;
	public TextView b1,b12,b13,b2,b22,b23,b3,b32,b33,b4,b42,b43;
	public TextView tex1,tex2,resultado;
	public String conl,s1,s2,s3;
	public Integer con2,s12,s22,s32,cant1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        id=(EditText) findViewById(R.id.editText1);
        nombre=(EditText) findViewById(R.id.editText2);
        cantidad=(EditText) findViewById(R.id.editText3);
        precio=(EditText) findViewById(R.id.editText4);
        
        b1=(TextView) findViewById(R.id.textView5);
        b12=(TextView) findViewById(R.id.textView6);
        b13=(TextView) findViewById(R.id.textView7);
        
        b2=(TextView) findViewById(R.id.textView8);
        b22=(TextView) findViewById(R.id.textView9);
        b23=(TextView) findViewById(R.id.textView10);
        
        b3=(TextView) findViewById(R.id.textView11);
        b32=(TextView) findViewById(R.id.textView12);
        b33=(TextView) findViewById(R.id.textView13);
        
 
        
        b4=(TextView) findViewById(R.id.textView14);
        b42=(TextView) findViewById(R.id.textView15);
        b43=(TextView) findViewById(R.id.textView16);
        
        resultado=(TextView) findViewById(R.id.textView23);
        
        
        Button eli1 = (Button) findViewById(R.id.button2);
        eli1.setVisibility(View.GONE);
        Button eli2 = (Button) findViewById(R.id.button3);
        eli2.setVisibility(View.GONE);
        Button eli3 = (Button) findViewById(R.id.Button01);
        eli3.setVisibility(View.GONE);
        Button eli4 = (Button) findViewById(R.id.button5);
        eli4.setVisibility(View.GONE);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    public void insertar(View view){
    	
    	if(b1.getText() == ""){
    		b1.setText( nombre.getText().toString());
    		b12.setText(cantidad.getText().toString());
    		b13.setText(precio.getText().toString());
    		
    		Button eli1 = (Button) findViewById(R.id.button2);
            eli1.setVisibility(View.VISIBLE);
            
            id.setText("");
            nombre.setText("");
            cantidad.setText("");
            precio.setText("");
    	}
    	
    	else if(b2.getText() == ""){
    		b2.setText( nombre.getText().toString());
    		b22.setText(cantidad.getText().toString());
    		b23.setText(precio.getText().toString());
    		
    		Button eli2 = (Button) findViewById(R.id.button3);
            eli2.setVisibility(View.VISIBLE);
            
            id.setText("");
            nombre.setText("");
            cantidad.setText("");
            precio.setText("");
    	}
    	else if(b3.getText() == ""){
    		b3.setText( nombre.getText().toString());
    		b32.setText(cantidad.getText().toString());
    		b33.setText(precio.getText().toString());
    		
    		Button eli3 = (Button) findViewById(R.id.Button01);
            eli3.setVisibility(View.VISIBLE);
            
            id.setText("");
            nombre.setText("");
            cantidad.setText("");
            precio.setText("");
    	}
    	else if(b4.getText() == ""){
    		b4.setText( nombre.getText().toString());
    		b42.setText(cantidad.getText().toString());
    		b43.setText(precio.getText().toString());
    		
    		Button eli4 = (Button) findViewById(R.id.button5);
            eli4.setVisibility(View.VISIBLE);
            
            id.setText("");
            nombre.setText("");
            cantidad.setText("");
            precio.setText("");
    	}
    	
    	
    	
    }
    
public void borrar1(View view){
	b1.setText("");
	b12.setText("");
	b13.setText("");
	
	Button eli1 = (Button) findViewById(R.id.button2);
    eli1.setVisibility(View.GONE);
    }
    
public void borrar2(View view){
	b2.setText("");
	b22.setText("");
	b23.setText("");
	
	Button eli2 = (Button) findViewById(R.id.button3);
    eli2.setVisibility(View.GONE);
    }
public void borrar3(View view){
	b3.setText("");
	b32.setText("");
	b33.setText("");
	
	Button eli3 = (Button) findViewById(R.id.Button01);
    eli3.setVisibility(View.GONE);
    }
public void borrar4(View view){
	b4.setText("");
	b42.setText("");
	b43.setText("");
	
	Button eli4 = (Button) findViewById(R.id.button5);
    eli4.setVisibility(View.GONE);
    }
    

public void comprarp(View view){

	
	tex1=(EditText) findViewById(R.id.nombre2);
	conl = tex1.getText().toString();
    
    tex2=(EditText) findViewById(R.id.cantidad2);
    con2 = Integer.parseInt(tex2.getText().toString());
    
   
    s1=b1.getText().toString();
    s12=Integer.parseInt(b12.getText().toString());
    
    s2=b2.getText().toString();
    s22=Integer.parseInt(b22.getText().toString());
    
    s3=b3.getText().toString();
    s32=Integer.parseInt(b32.getText().toString());
    
    if(conl.equals(s1)){
    	if(con2 <= s12 ){
    		b12.setText(Integer.toString((s12-con2))); 
    		
    		cant1=Integer.parseInt(b13.getText().toString());
    		resultado.setText(Integer.toString((cant1*con2))); 
    	}else{
    		Toast t=Toast.makeText(this,"NO Hay producto!", Toast.LENGTH_SHORT);
    		t.show();
    	}
    }
    else if(conl.equals(s2)) {
    	if(con2 <= s22 ){
    		b22.setText(Integer.toString((s22-con2))); 
    		
    		cant1=Integer.parseInt(b23.getText().toString());
    		resultado.setText(Integer.toString((cant1*con2))); 
    	}else{
    		Toast t=Toast.makeText(this,"NO Hay producto!", Toast.LENGTH_SHORT);
    		t.show();
    	}
     
    }
    else if(conl.equals(s3)) {
    	if(con2 <= s32 ){
    		b32.setText(Integer.toString((s32-con2))); 
    		
    		cant1=Integer.parseInt(b33.getText().toString());
    		resultado.setText(Integer.toString((cant1*con2))); 
    	}else{
    		Toast t=Toast.makeText(this,"NO Hay producto!", Toast.LENGTH_SHORT);
    		t.show();
    	}
    

    
}

    
	  
}
}
