package com.example.sueldo;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	public EditText nombre,puesto,hr,paga;
	public TextView r1,r2,r3,r4;
    public double c1,c2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        
        nombre=(EditText) findViewById(R.id.editText1);
        puesto=(EditText) findViewById(R.id.EditText01);
        
        hr=(EditText) findViewById(R.id.editText2);
        paga=(EditText) findViewById(R.id.editText3);
        
        r1=(TextView) findViewById(R.id.textView4);
        r2=(TextView) findViewById(R.id.textView5);
        r3=(TextView) findViewById(R.id.textView6);
        r4=(TextView) findViewById(R.id.textView7);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    public void calcula(View view){
    	
    	 c1=Double.parseDouble(hr.getText().toString());
    	 c2=Double.parseDouble(paga.getText().toString());
    	
    	 
    	 if(r1.getText() == ""){
    		 r1.setText( nombre.getText().toString()
         		    + " - " + puesto.getText().toString()
         		    + " - " + hr.getText().toString()
         		    + " - $" +Double.toString(c1*c2)
         		);
    	 }else if(r2.getText() == ""){
    		 r2.setText( nombre.getText().toString()
          		    + " - " + puesto.getText().toString()
          		    + " - " + hr.getText().toString()
          		    + " - $" +Double.toString(c1*c2)
          		);
    	 }
          else if(r3.getText() == ""){
        	  r3.setText( nombre.getText().toString()
           		    + " - " + puesto.getText().toString()
           		    + " - " + hr.getText().toString()
           		    + " - $" +Double.toString(c1*c2)
           		);
    	 }
          else if(r4.getText() == ""){
        	  r4.setText( nombre.getText().toString()
           		    + " - " + puesto.getText().toString()
           		    + " - " + hr.getText().toString()
           		    + " - $" +Double.toString(c1*c2)
           		);
     	 }
    	 
       
        nombre.setText("");
        puesto.setText("");
        hr.setText("");
        paga.setText("");
    }
    
    public void del(View view){
    	r1.setText("");
    	r2.setText("");
    	r3.setText("");
    	r4.setText("");
    	
    }
    
    
}
