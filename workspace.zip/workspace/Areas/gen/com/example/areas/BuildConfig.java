/** Automatically generated file. DO NOT MODIFY */
package com.example.areas;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}