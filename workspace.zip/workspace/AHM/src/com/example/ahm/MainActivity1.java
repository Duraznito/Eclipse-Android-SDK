package com.example.ahm;

import android.os.Bundle;
import java.awt.*;

import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity1 extends Activity {
	public TextView tex1,tex2,tex3,Resultadof,tex5,tex6,text5,text6;
	public String conl,con2,con3;
	public EditText ladol;
	public double A1,radio=0, PI=3.1418,base1,base2,altura3,dos=2,baser,altr,BB,AA,e1,e2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main_activity1);
		
		tex1=(TextView) findViewById(R.id.texto1);
		tex2=(TextView) findViewById(R.id.tex2);
		tex3=(TextView) findViewById(R.id.tex3);
		tex1.setVisibility(View.GONE);
		tex2.setVisibility(View.GONE);
		tex3.setVisibility(View.GONE);
		
		tex5=(EditText) findViewById(R.id.b2);
		tex5.setVisibility(View.GONE);
		
		tex6=(EditText) findViewById(R.id.altura1);
		tex6.setVisibility(View.GONE);
		
		
		text5=(TextView) findViewById(R.id.BAS2);
		text6=(TextView) findViewById(R.id.AL2);
		text5.setVisibility(View.GONE);
		text6.setVisibility(View.GONE);
		
        Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.GONE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.GONE); 
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE); 
	   
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE); 
	   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
	   	
	   	
	 // Oculta lado y resultado.
	   	ladol = (EditText) findViewById(R.id.ladoc);
	   	Resultadof=(TextView) findViewById(R.id.resultadof);
	   	
	   	//ocultar
	   	ladol.setVisibility(View.GONE);
	   	Resultadof.setVisibility(View.GONE);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_activity1, menu);
		return true;
	}

	  
    public void cuadrado(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.VISIBLE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.INVISIBLE);
	         
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE); 
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
	   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
	   	
	        
    	Button b1 = (Button) findViewById(R.id.circulo);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.trapecio);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.rectangulo);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.triangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.INVISIBLE);
    	
    	//mostrar
//		nuevo nombre a label
    	tex2.setText("lado");	
    	//ocultar
	   	ladol.setVisibility(View.VISIBLE);
	   	Resultadof.setVisibility(View.VISIBLE);
    	

    	    }
    
    public void circulo(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		
		
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.INVISIBLE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.VISIBLE);
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE); 
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
	   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
	   	
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.trapecio);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.rectangulo);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.triangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.INVISIBLE);
    	
    	//	nuevo nombre a label
    	tex2.setText("Radio");	  
    	
    	//mostrar
    	ladol.setVisibility(View.VISIBLE);
	   	Resultadof.setVisibility(View.VISIBLE);
    }
    
    public void trapecio(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.INVISIBLE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.INVISIBLE);
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.VISIBLE); 
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
	   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
	   	
	   	
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.circulo);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.rectangulo);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.triangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.INVISIBLE);
    	

		text5.setVisibility(View.VISIBLE);
		text6.setVisibility(View.VISIBLE);
//    	nuevo nombre a label
    	tex2.setText("Base1");
    	text5.setText("Base2");
    	
    	//mostrar
    	ladol.setVisibility(View.VISIBLE);
    	tex5.setVisibility(View.VISIBLE);
    	tex6.setVisibility(View.VISIBLE);
    	
	   	Resultadof.setVisibility(View.VISIBLE);
	   	
	   	
	   	
	   	
	   	
	   	
    	    }
    
    public void rectangulo(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		
		tex5.setVisibility(View.VISIBLE);		
		text5.setVisibility(View.VISIBLE);
		ladol.setVisibility(View.VISIBLE);
		
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.INVISIBLE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.INVISIBLE);
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.INVISIBLE);
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.VISIBLE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
	   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
	   	
	   	
	   	
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.circulo);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.trapecio);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.triangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.INVISIBLE);
    	
    	Resultadof.setVisibility(View.VISIBLE);
//    	nuevo nombre a label
    	tex2.setText("Base");
    	text5.setText("Altura");
    	
    	    }
    
    public void triangulo(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		text5.setVisibility(View.VISIBLE);
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.GONE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.GONE);
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE);
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.VISIBLE);
		   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.GONE); 
	   	
		   	
		   	
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.circulo);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.trapecio);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.rectangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.INVISIBLE);
    	
    	
//    	nuevo nombre a label 
    	tex2.setText("Base");
    	text5.setText("Altura");
    	
    	//muestra los edit
    	ladol.setVisibility(View.VISIBLE);
    	tex5.setVisibility(View.VISIBLE);
    	Resultadof.setVisibility(View.VISIBLE);
    	
    	    }
    
    
    public void elipse(View view){
    	tex1.setVisibility(View.VISIBLE);
    	tex2.setVisibility(View.VISIBLE);
		tex3.setVisibility(View.VISIBLE);
		
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.GONE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.GONE);
	   	
	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE);
	   	
	 	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
		   	
	   	Button calc6 = (Button) findViewById(R.id.elipses);
	   	calc6.setVisibility(View.VISIBLE); 
	   	
	   	
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.INVISIBLE);
    	
    	Button b2 = (Button) findViewById(R.id.circulo);
    	b2.setVisibility(View.INVISIBLE);
    	
    	Button b3 = (Button) findViewById(R.id.trapecio);
    	b3.setVisibility(View.INVISIBLE);
    	
    	Button b4 = (Button) findViewById(R.id.rectangulo);
    	b4.setVisibility(View.INVISIBLE);
    	
    	Button b5 = (Button) findViewById(R.id.triangulo);
    	b5.setVisibility(View.INVISIBLE);
    	
    	//labels
    	text5.setVisibility(View.VISIBLE);
    	
    	
    	tex2.setText("lado a");
    	text5.setText("lado b");
    	
    	//muestra los edit
    	ladol.setVisibility(View.VISIBLE);
    	tex5.setVisibility(View.VISIBLE);
    	
    	
    	Resultadof.setVisibility(View.VISIBLE);
	   	calc6.setVisibility(View.VISIBLE); 
    	    }
    
    

    
    public void ahm(View view){
    
    	tex1.setVisibility(View.GONE);
    	tex2.setVisibility(View.GONE);
		tex3.setVisibility(View.GONE);
		
		
    	Button b1 = (Button) findViewById(R.id.Button05);
    	b1.setVisibility(View.VISIBLE);
    	Button b6 = (Button) findViewById(R.id.circulo);
    	b6.setVisibility(View.VISIBLE);
    	Button b2 = (Button) findViewById(R.id.trapecio);
    	b2.setVisibility(View.VISIBLE);
    	Button b3 = (Button) findViewById(R.id.rectangulo);
    	b3.setVisibility(View.VISIBLE);
    	Button b4 = (Button) findViewById(R.id.triangulo);
    	b4.setVisibility(View.VISIBLE);
    	Button b5 = (Button) findViewById(R.id.elipse);
    	b5.setVisibility(View.VISIBLE);
    	
    	
		Button calc = (Button) findViewById(R.id.cc);
	   	calc.setVisibility(View.GONE); 
     
	   	Button calc2 = (Button) findViewById(R.id.calcular2);
	   	calc2.setVisibility(View.GONE);

	   	Button calc3 = (Button) findViewById(R.id.calculart);
	   	calc3.setVisibility(View.GONE);
	   	
	   	Button calc4 = (Button) findViewById(R.id.calcularec);
	   	calc4.setVisibility(View.GONE); 
	   	
	   	Button calc5 = (Button) findViewById(R.id.triang);
	   	calc5.setVisibility(View.GONE);
	   	
	   	
 	    ladol.setVisibility(View.GONE);
	   	Resultadof.setVisibility(View.GONE);
	   	Resultadof.setText("0");
	     
	   	
	   	tex5.setVisibility(View.GONE);
    	tex6.setVisibility(View.GONE);
		text6.setVisibility(View.GONE);
		text5.setVisibility(View.GONE);
		text5.setText("");
		
		Intent salida=new Intent( this, MainActivity.class); //Llamando a la activity principal
		finish(); // La cerramos.
		
    	    }
    
    
    public void calculo(View view){
    	//convierto de edit txt a string
    	tex1=(EditText) findViewById(R.id.ladoc);
	     conl = tex1.getText().toString();
  	
	      if(TextUtils.isEmpty(conl)) {
	    	  tex1.setError("esta vacio");
	      } else{
	     A1 = Double.parseDouble(tex1.getText().toString());
	     Resultadof.setText(Double.toString( A1 * A1 ));
	     
	      }
    }
    
    public void calcular2(View view){
    	  tex1=(EditText) findViewById(R.id.ladoc);
    	  conl = tex1.getText().toString();

	      if(TextUtils.isEmpty(conl)) {
	    	  tex1.setError("esta vacio");
	      } else{
	    	  radio = Double.parseDouble(tex1.getText().toString());
	    	  Resultadof.setText(Double.toString( PI * (radio * radio )));
	      }
    }
    
    
    public void calculart(View view){
  	  tex1=(EditText) findViewById(R.id.ladoc);
  	  conl = tex1.getText().toString();
  	  
      text5=(EditText) findViewById(R.id.b2);
	  con2 = text5.getText().toString();
	  
	  text6=(EditText) findViewById(R.id.altura1);
  	  con3 = text6.getText().toString();

  	  
  	  
	      if(TextUtils.isEmpty(conl)) {
	    	  tex1.setError("esta vacio");
	      } else{
	    	  base1 = Double.parseDouble(tex1.getText().toString());
	    	  base2 = Double.parseDouble(text5.getText().toString());
	    	  altura3 = Double.parseDouble(text6.getText().toString());
	    	 
	    	  Resultadof.setText(Double.toString(((base1 + base2 )/dos)*altura3));      	
          }
   }
   
    public void calcularect(View view){
    	 tex1=(EditText) findViewById(R.id.ladoc);
     	  conl = tex1.getText().toString();
     	  
         text5=(EditText) findViewById(R.id.b2);
   	  con2 = text5.getText().toString();
   	  
   	  if(TextUtils.isEmpty(conl)) {
    	  tex1.setError("esta vacio");
      } else{
    	  baser = Double.parseDouble(tex1.getText().toString());
    	  altr = Double.parseDouble(text5.getText().toString());
    	 
    	  Resultadof.setText(Double.toString(baser*altr));      	
      }
   	  
    }
    
    
    public void triangu(View view){
    	 tex1=(EditText) findViewById(R.id.ladoc);
    	  conl = tex1.getText().toString();
    	  
        text5=(EditText) findViewById(R.id.b2);
  	  con2 = text5.getText().toString();
  	  
  	  if(TextUtils.isEmpty(conl)) {
   	  tex1.setError("esta vacio");
     } else{
   	  BB = Double.parseDouble(tex1.getText().toString());
   	  AA = Double.parseDouble(text5.getText().toString());
   	 
   	  Resultadof.setText(Double.toString((BB*AA)/dos));      	
     }
  	  
   }
    
    
    
    public void elipp(View view){
    	 tex1=(EditText) findViewById(R.id.ladoc);
   	  conl = tex1.getText().toString();
   	  
       text5=(EditText) findViewById(R.id.b2);
 	  con2 = text5.getText().toString();
 	  
 	  if(TextUtils.isEmpty(conl)) {
  	  tex1.setError("esta vacio");
    } else{
  	  e1 = Double.parseDouble(tex1.getText().toString());
  	  e2 = Double.parseDouble(text5.getText().toString());
  	 
  	  Resultadof.setText(Double.toString((e1*e2*PI)));      	
    }
    	
     }
  	  
   
    
    
    
}
