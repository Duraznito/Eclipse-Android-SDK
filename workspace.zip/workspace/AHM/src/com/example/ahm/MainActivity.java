package com.example.ahm;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.Window;

public class MainActivity extends Activity {
	 private final int DURACION_SPLASH = 2000;
	 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        //AHM con esta liena se oculta la barra de titulo
       
        setContentView(R.layout.activity_main);
        new Handler().postDelayed(new Runnable(){
          
        	//abre la siguiente pantalla
        	public void run(){
                Intent intent = new Intent(MainActivity.this, MainActivity1.class);
                startActivity(intent);
                finish();
            };
        }, DURACION_SPLASH);
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
